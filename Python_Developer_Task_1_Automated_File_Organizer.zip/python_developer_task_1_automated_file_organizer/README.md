# Python Developer Task 1 — Automated File Organizer

A command-line Python utility that scans a directory recursively and organizes files into folders based on file extension.

## Features

- Recursively scans directories and subdirectories.
- Skips directories and symbolic links.
- Categorizes files such as:
  - `.py` → `Python_Code`
  - `.txt`, `.doc`, `.docx`, `.pdf` → `Documents`
  - `.jpg`, `.jpeg`, `.png`, `.gif` → `Images`
  - `.csv`, `.xlsx` → `Spreadsheets`
  - `.zip`, `.rar`, `.7z` → `Archives`
  - `.mp3`, `.wav` → `Audio`
  - `.mp4`, `.mkv` → `Videos`
  - `.html`, `.css`, `.js` → `Web`
  - unknown extensions → `Other`
- Handles filename conflicts with names such as `report(1).txt`, `report(2).txt`, etc.
- Handles invalid paths and common filesystem errors without crashing.
- Logs operations with timestamps.
- Produces a summary report showing moved files and errors.
- Supports `--dry-run` so changes can be previewed before files are moved.
- Includes automated tests using Python's built-in `unittest` framework.

## Requirements

- Python 3.9 or newer
- No third-party packages are required.

## Project Structure

```text
python-developer-task-1/
├── organizer.py
├── README.md
├── requirements.txt
├── .gitignore
└── tests/
    └── test_organizer.py
```

## Usage

### Preview changes first

```bash
python organizer.py "/path/to/folder" --dry-run
```

### Organize files

```bash
python organizer.py "/path/to/folder"
```

### Custom log and report locations

```bash
python organizer.py "/path/to/folder" --log-file organizer.log --report-file organizer_report.txt
```

On Windows, an example is:

```powershell
python organizer.py "C:\Users\Harsh\Downloads" --dry-run
```

Run the dry-run first. It shows what would happen without moving files.

## Example

Before:

```text
sample/
├── report.txt
├── photo.jpg
├── script.py
└── unknown.xyz
```

After:

```text
sample/
├── Documents/
│   └── report.txt
├── Images/
│   └── photo.jpg
├── Python_Code/
│   └── script.py
└── Other/
    └── unknown.xyz
```

If `Documents/report.txt` already exists, the organizer creates:

```text
Documents/report(1).txt
```

## Logging and Reporting

Each run records timestamped activity in the configured log file. The report contains:

- source directory
- dry-run status
- files discovered
- files moved/planned
- errors
- category counts

## Testing

Run:

```bash
python -m unittest discover -s tests -v
```

The tests cover:

- extension-based categorization
- dry-run behavior
- recursive scanning
- unknown extensions
- filename conflict handling
- successful file movement

## Notes

This project is designed as an internship-task implementation. Review and understand the code before submitting it, and customize the README/project details as appropriate for your own work.
