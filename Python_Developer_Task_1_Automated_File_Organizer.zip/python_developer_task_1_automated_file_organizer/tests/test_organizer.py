import tempfile
import unittest
from pathlib import Path

from organizer import category_for, organize_directory, setup_logger


class TestAutomatedFileOrganizer(unittest.TestCase):

    def make_logger(self, folder: Path):
        # Keep test logs outside the directory being organized so they are
        # not treated as input files.
        log_path = Path(tempfile.gettempdir()) / "automated_file_organizer_test.log"
        return setup_logger(log_path)

    def test_category_detection(self):
        self.assertEqual(category_for(Path("photo.JPG")), "Images")
        self.assertEqual(category_for(Path("script.py")), "Python_Code")
        self.assertEqual(category_for(Path("notes.txt")), "Documents")
        self.assertEqual(category_for(Path("unknown.xyz")), "Other")

    def test_dry_run_does_not_move_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "notes.txt").write_text("hello", encoding="utf-8")

            result = organize_directory(
                root,
                dry_run=True,
                logger=self.make_logger(root),
            )

            self.assertEqual(result.discovered, 1)
            self.assertEqual(result.moved, 1)
            self.assertTrue((root / "notes.txt").exists())
            self.assertFalse((root / "Documents" / "notes.txt").exists())

    def test_files_are_moved_to_categories(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "photo.jpg").write_bytes(b"image")
            (root / "script.py").write_text("print('hello')", encoding="utf-8")
            (root / "data.xyz").write_text("other", encoding="utf-8")

            result = organize_directory(
                root,
                dry_run=False,
                logger=self.make_logger(root),
            )

            self.assertEqual(result.errors, 0)
            self.assertTrue((root / "Images" / "photo.jpg").exists())
            self.assertTrue((root / "Python_Code" / "script.py").exists())
            self.assertTrue((root / "Other" / "data.xyz").exists())

    def test_recursive_scanning(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            nested = root / "nested" / "deeper"
            nested.mkdir(parents=True)
            (nested / "document.pdf").write_bytes(b"pdf")

            result = organize_directory(
                root,
                dry_run=False,
                logger=self.make_logger(root),
            )

            self.assertEqual(result.errors, 0)
            self.assertTrue((root / "Documents" / "document.pdf").exists())

    def test_filename_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            docs = root / "Documents"
            docs.mkdir()
            (docs / "report.txt").write_text("old", encoding="utf-8")
            (root / "report.txt").write_text("new", encoding="utf-8")

            result = organize_directory(
                root,
                dry_run=False,
                logger=self.make_logger(root),
            )

            self.assertEqual(result.errors, 0)
            self.assertTrue((docs / "report.txt").exists())
            self.assertTrue((docs / "report(1).txt").exists())

    def test_existing_category_folder_is_not_recursively_reorganized(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            docs = root / "Documents"
            docs.mkdir()
            (docs / "existing.txt").write_text("already organized", encoding="utf-8")

            result = organize_directory(
                root,
                dry_run=False,
                logger=self.make_logger(root),
            )

            self.assertEqual(result.discovered, 0)
            self.assertTrue((docs / "existing.txt").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
