"""
Automated File Organizer
Python Developer Task 1

Recursively organizes files into category folders based on file extension.
"""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import sys
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional


CATEGORIES: Dict[str, str] = {
    ".py": "Python_Code",
    ".pyw": "Python_Code",
    ".txt": "Documents",
    ".doc": "Documents",
    ".docx": "Documents",
    ".pdf": "Documents",
    ".jpg": "Images",
    ".jpeg": "Images",
    ".png": "Images",
    ".gif": "Images",
    ".bmp": "Images",
    ".webp": "Images",
    ".csv": "Spreadsheets",
    ".xls": "Spreadsheets",
    ".xlsx": "Spreadsheets",
    ".ods": "Spreadsheets",
    ".zip": "Archives",
    ".rar": "Archives",
    ".7z": "Archives",
    ".tar": "Archives",
    ".gz": "Archives",
    ".mp3": "Audio",
    ".wav": "Audio",
    ".flac": "Audio",
    ".mp4": "Videos",
    ".mkv": "Videos",
    ".avi": "Videos",
    ".mov": "Videos",
    ".html": "Web",
    ".htm": "Web",
    ".css": "Web",
    ".js": "Web",
}

DEFAULT_EXCLUDED_DIRS = set(CATEGORIES.values()) | {"__pycache__", ".git"}


@dataclass
class OrganizerResult:
    discovered: int = 0
    moved: int = 0
    errors: int = 0
    dry_run: bool = False
    categories: Counter = field(default_factory=Counter)
    error_messages: List[str] = field(default_factory=list)


def category_for(path: Path) -> str:
    """Return the destination category for a file."""
    return CATEGORIES.get(path.suffix.lower(), "Other")


def unique_destination(destination_dir: Path, filename: str) -> Path:
    """
    Return a non-conflicting destination path.

    Example:
        report.txt
        report(1).txt
        report(2).txt
    """
    candidate = destination_dir / filename
    if not candidate.exists():
        return candidate

    source = Path(filename)
    index = 1
    while True:
        candidate = destination_dir / f"{source.stem}({index}){source.suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def setup_logger(log_file: Path) -> logging.Logger:
    """Create a file logger with timestamps."""
    logger = logging.getLogger("automated_file_organizer")
    logger.setLevel(logging.INFO)
    for old_handler in logger.handlers[:]:
        old_handler.close()
        logger.removeHandler(old_handler)
    logger.propagate = False

    log_file.parent.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(log_file, encoding="utf-8")
    handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    )
    logger.addHandler(handler)
    return logger


def iter_files(source: Path, excluded_dirs: Optional[Iterable[str]] = None):
    """
    Recursively yield regular files while skipping directories and symlinks.

    os.walk is used with followlinks=False so directory symlinks are not followed.
    """
    excluded = set(excluded_dirs or DEFAULT_EXCLUDED_DIRS)

    def on_walk_error(error: OSError) -> None:
        # os.walk may call this for an inaccessible directory.
        logging.getLogger("automated_file_organizer").error(
            "Directory access error: %s", error
        )

    for root, dirs, filenames in os.walk(
        source, topdown=True, followlinks=False, onerror=on_walk_error
    ):
        # Remove excluded directories and symlink directories from traversal.
        dirs[:] = [
            d for d in dirs
            if d not in excluded and not (Path(root) / d).is_symlink()
        ]

        for filename in filenames:
            path = Path(root) / filename
            if path.is_symlink():
                continue
            try:
                if path.is_file():
                    yield path
            except OSError:
                # A file can disappear or become inaccessible during scanning.
                continue


def organize_directory(
    source: Path,
    dry_run: bool = False,
    logger: Optional[logging.Logger] = None,
) -> OrganizerResult:
    """Organize files under source and return a summary result."""
    if logger is None:
        logger = logging.getLogger("automated_file_organizer")

    result = OrganizerResult(dry_run=dry_run)

    for item in iter_files(source):
        result.discovered += 1

        try:
            category = category_for(item)
            result.categories[category] += 1

            size = item.stat().st_size
            modified = datetime.fromtimestamp(item.stat().st_mtime).isoformat(
                timespec="seconds"
            )

            destination_dir = source / category
            destination = unique_destination(destination_dir, item.name)

            message = (
                f"{'DRY-RUN: ' if dry_run else ''}"
                f"{item} -> {destination} | size={size} bytes | modified={modified}"
            )
            logger.info(message)

            if not dry_run:
                destination_dir.mkdir(parents=True, exist_ok=True)
                # shutil.move preserves the file and is appropriate for moving
                # files into category folders on the same filesystem.
                shutil.move(str(item), str(destination))

            result.moved += 1

        except (PermissionError, FileNotFoundError, OSError) as exc:
            result.errors += 1
            error_message = f"{item}: {type(exc).__name__}: {exc}"
            result.error_messages.append(error_message)
            logger.error("FAILED: %s", error_message)

    logger.info(
        "Run complete | discovered=%d | moved/planned=%d | errors=%d | dry_run=%s",
        result.discovered,
        result.moved,
        result.errors,
        result.dry_run,
    )
    return result


def write_report(
    report_file: Path,
    source: Path,
    result: OrganizerResult,
) -> None:
    """Write a human-readable summary report."""
    lines = [
        "AUTOMATED FILE ORGANIZER - SUMMARY REPORT",
        "=" * 48,
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"Source: {source}",
        f"Dry run: {'Yes' if result.dry_run else 'No'}",
        "",
        f"Files discovered: {result.discovered}",
        f"Files moved/planned: {result.moved}",
        f"Errors: {result.errors}",
        "",
        "Category counts:",
    ]

    for category, count in sorted(result.categories.items()):
        lines.append(f"  - {category}: {count}")

    if result.error_messages:
        lines.extend(["", "Errors encountered:"])
        lines.extend(f"  - {message}" for message in result.error_messages)

    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Organize files recursively by extension."
    )
    parser.add_argument(
        "source",
        help="Directory to organize",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without moving files",
    )
    parser.add_argument(
        "--log-file",
        default="organizer.log",
        help="Path for the operation log (default: organizer.log)",
    )
    parser.add_argument(
        "--report-file",
        default="organizer_report.txt",
        help="Path for the summary report (default: organizer_report.txt)",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    source = Path(args.source).expanduser()

    if not source.exists():
        print(f"Error: source directory does not exist: {source}", file=sys.stderr)
        return 1

    if not source.is_dir():
        print(f"Error: source path is not a directory: {source}", file=sys.stderr)
        return 1

    log_file = Path(args.log_file).expanduser()
    report_file = Path(args.report_file).expanduser()
    logger = setup_logger(log_file)

    logger.info("Starting organizer for source=%s", source.resolve())
    result = organize_directory(source.resolve(), args.dry_run, logger)
    write_report(report_file, source.resolve(), result)

    print("\nAutomated File Organizer")
    print("-" * 28)
    print(f"Source directory : {source.resolve()}")
    print(f"Dry run          : {'Yes' if args.dry_run else 'No'}")
    print(f"Files discovered : {result.discovered}")
    print(f"Files moved/planned: {result.moved}")
    print(f"Errors           : {result.errors}")
    print(f"Log file         : {log_file.resolve()}")
    print(f"Report file      : {report_file.resolve()}")

    return 0 if result.errors == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
